package com.milkbar.dao;

/**
 * Customer entity. @author MyEclipse Persistence Tools
 */

public class Customer implements java.io.Serializable {

	// Fields

	private Integer id;
	private String name;
	private Integer telnum;
	private String address;
	private String period;
	private String starttime;
	private String endtime;
	private String other;

	// Constructors

	/** default constructor */
	public Customer() {
	}

	/** minimal constructor */
	public Customer(Integer id, String name, Integer telnum, String address,
			String period, String starttime, String endtime) {
		this.id = id;
		this.name = name;
		this.telnum = telnum;
		this.address = address;
		this.period = period;
		this.starttime = starttime;
		this.endtime = endtime;
	}

	/** full constructor */
	public Customer(Integer id, String name, Integer telnum, String address,
			String period, String starttime, String endtime, String other) {
		this.id = id;
		this.name = name;
		this.telnum = telnum;
		this.address = address;
		this.period = period;
		this.starttime = starttime;
		this.endtime = endtime;
		this.other = other;
	}

	// Property accessors

	public Integer getId() {
		return this.id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getName() {
		return this.name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Integer getTelnum() {
		return this.telnum;
	}

	public void setTelnum(Integer telnum) {
		this.telnum = telnum;
	}

	public String getAddress() {
		return this.address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getPeriod() {
		return this.period;
	}

	public void setPeriod(String period) {
		this.period = period;
	}

	public String getStarttime() {
		return this.starttime;
	}

	public void setStarttime(String starttime) {
		this.starttime = starttime;
	}

	public String getEndtime() {
		return this.endtime;
	}

	public void setEndtime(String endtime) {
		this.endtime = endtime;
	}

	public String getOther() {
		return this.other;
	}

	public void setOther(String other) {
		this.other = other;
	}

}