package com.milkbar.dao;

/**
 * Milk entity. @author MyEclipse Persistence Tools
 */

public class Milk implements java.io.Serializable {

	// Fields

	private Integer id;
	private Integer type;

	// Constructors

	/** default constructor */
	public Milk() {
	}

	/** full constructor */
	public Milk(Integer id, Integer type) {
		this.id = id;
		this.type = type;
	}

	// Property accessors

	public Integer getId() {
		return this.id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public Integer getType() {
		return this.type;
	}

	public void setType(Integer type) {
		this.type = type;
	}

}