package milkbar.ui;

import java.awt.Color;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.List;
import java.util.Vector;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;

import uml.hotel.utils.CustomTableModel;

import com.milkbar.dao.Customer;
import com.milkbar.dao.CustomerDAO;

public class AllOderFrame extends JFrame {

	private JPanel contentPane;
	private JTable table;
	private final JLabel label = new JLabel("\u8BA2\u5355\u4FE1\u606F\uFF1A");
	private Vector<Vector<Object>> data = new Vector<Vector<Object>>(); 
	private List<Customer> list_getCustomers;
	private static CustomerDAO customerDAO;
	//public JCheckBox checkbox = new JCheckBox("ȡ��");
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				customerDAO = new CustomerDAO();
				try {
					AllOderFrame frame = new AllOderFrame();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public AllOderFrame() {
		customerDAO = new CustomerDAO();
		setTitle("\u5168\u90E8\u8BA2\u5355\u4FE1\u606F");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 484, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		final JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(10, 51, 448, 159);
		contentPane.add(scrollPane);
		
		CustomTableModel model = new CustomTableModel();
		String[] names = {"�ͻ�����", "����Ʒ��", "�绰", "סַ", "����ʱ��", "��ʼʱ��", "����ʱ��"};
		table = new JTable(model);
		model.setColumnNames(names);
		
		updateTable();
		model.setData(data);
		scrollPane.setViewportView(table);
		
		label.setForeground(Color.DARK_GRAY);
		label.setFont(new Font("����", Font.PLAIN, 16));
		label.setBounds(47, 10, 109, 31);
		contentPane.add(label);
		
		JButton button = new JButton("\u8FD4\u56DE");
		button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				setVisible(false);
				new MainFrame().setVisible(true);
			}
		});
		button.setBounds(350, 228, 93, 23);
		contentPane.add(button);
		
		JButton button_1 = new JButton("\u5220\u9664");
		button_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				int row = table.getSelectedRow();
				Customer customer = new Customer();
				customer = list_getCustomers.get(row);
				customerDAO.delete(customer);
				
				CustomTableModel model = new CustomTableModel();
				String[] names = {"�ͻ�����", "����Ʒ��", "�绰", "סַ", "����ʱ��", "��ʼʱ��", "����ʱ��"};
				model.setColumnNames(names);
				
				updateTable();
				model.setData(data);
				((DefaultTableModel) table.getModel()).getDataVector().removeAllElements(); 
				((DefaultTableModel)table.getModel()).fireTableDataChanged(); 
				table.updateUI();
				table.setModel(model);
			}
		});
		button_1.setBounds(350, 15, 93, 23);
		contentPane.add(button_1);
	}
	public void updateTable() {
		data = new Vector<Vector<Object>>();
		CustomerDAO customerDAO = new CustomerDAO();
		List<Customer> list =customerDAO.findAll();
		list_getCustomers = list;
			for (Customer customer : list) {
				
				Vector<Object> row = new Vector<Object>();
				row.add(customer.getName());
				
				String mtype = null ;
			    if(customer.getOther().equals("0")){
			    	mtype = "����";
			    }
			    else if(customer.getOther().equals("1")){
					mtype = "����";
				}
			    else if(customer.getOther().equals("2")) {
					mtype = "����";
				}
			    else if(customer.getOther().equals("3")) {
					mtype = "˫Ƥ��";
				}
			    row.add(mtype);
			    row.add(customer.getTelnum());
			    row.add(customer.getAddress());
				row.add(customer.getPeriod());
				row.add(customer.getStarttime());
				row.add(customer.getEndtime());
				data.add(row);
			}
	}
}
