package milkbar.ui;

import java.awt.BorderLayout;
import java.awt.Component;
import java.awt.EventQueue;
import java.awt.Image;
import java.awt.Point;
import java.net.URL;


import java.util.List;

import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import javax.swing.JButton;





import com.milkbar.dao.Admain;
import com.milkbar.dao.AdmainDAO;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;


public class LoginInFrame extends JFrame {

	private JPanel contentPane;
	private JTextField admain;
	private JTextField password;
private static JFrame frame=null;
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					frame = new LoginInFrame();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public LoginInFrame() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 421, 292);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		
		 
		setTitle("MilkBar");
		
	    contentPane.setLayout(null);
		
		admain = new JTextField();
		admain.setBounds(265, 158, 117, 21);
		getContentPane().add(admain);
		admain.setColumns(10);
		
		password = new JTextField();
		password.setHorizontalAlignment(SwingConstants.LEFT);
		password.setBounds(265, 189, 117, 21);
		//getContentPane().add(password);
		contentPane.add(password);
		password.setColumns(10);
		
		ImageIcon bg=new ImageIcon("src/pic/30c40e020f63f81f-c00171587126b6cf-afccdfb05ef10dd1ea14aeea7551f78e_i.jpg");
		JLabel imgLabel = new JLabel(bg);
		imgLabel.setBounds(191,0,214, 148);//���ñ�����ǩ��λ��
		contentPane.add(imgLabel, new Integer(Integer.MIN_VALUE));
		
		ImageIcon bg2=new ImageIcon("src/pic/2.jpg");
		JLabel imgLabel2 = new JLabel(bg2);
		imgLabel2.setBounds(0,0,189, 243);//���ñ�����ǩ��λ��
		contentPane.add(imgLabel2, new Integer(Integer.MIN_VALUE));
		
		JButton btnNewButton = new JButton("\u767B\u5165");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				String passwd = password.getText();
				String user = admain.getText();
				
				
				AdmainDAO admainDao = new AdmainDAO();
				List<Admain> list_of_nameAdmains=admainDao.findByUsername(user);
				//List<Admain> list_of_passwordAdmains=admainDao.findByPassword(passwd); 
				if ((list_of_nameAdmains.size() !=0)&&(list_of_nameAdmains.get(0).getPassword().toString().equalsIgnoreCase(passwd)) ){
					setVisible(false);
					new MainFrame().setVisible(true);
				} else {
					JOptionPane.showMessageDialog(null, "�û������������");
				}
			}
		});
		btnNewButton.setBounds(199, 220, 93, 23);
		contentPane.add(btnNewButton);
		
		JButton button = new JButton("\u53D6\u6D88");
		button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				setVisible(false);
				System.exit(0);
			}
		});
		button.setBounds(302, 220, 93, 23);
		contentPane.add(button);
		
		JLabel label = new JLabel("\u8D26\u6237");
		label.setBounds(200, 159, 31, 18);
		contentPane.add(label);
		
		JLabel label_1 = new JLabel("\u5BC6\u7801");
		label_1.setBounds(200, 192, 31, 15);
		contentPane.add(label_1);
	}
}
