package milkbar.ui;

import java.awt.BorderLayout;
import java.awt.Component;
import java.awt.EventQueue;
import java.awt.Image;
import java.awt.Point;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.SwingConstants;
import javax.swing.JLabel;








import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.net.URL;
import java.util.List;
import java.util.Vector;

import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;
import javax.swing.JScrollPane;
import javax.swing.JScrollBar;





import uml.hotel.utils.CustomTableModel;

import com.milkbar.dao.Customer;
import com.milkbar.dao.CustomerDAO;

import java.awt.Font;
import java.awt.Color;

public class MainFrame extends JFrame {

	private JPanel contentPane;
	private JTable table;
	private Vector<Vector<Object>> data = new Vector<Vector<Object>>();
	
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					MainFrame frame = new MainFrame();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public MainFrame() {
		setTitle("\u4E00\u5FC3\u5976\u5427  V1.0");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 431, 414);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JButton btnNewButton = new JButton("\u65B0\u589E");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				setVisible(false);
				new NewOderFrame().setVisible(true);
			}
		});
		btnNewButton.setToolTipText("");
		btnNewButton.setVerticalAlignment(SwingConstants.BOTTOM);
		btnNewButton.setBounds(10, -1, 60, 80);
		contentPane.add(btnNewButton);
		
		JButton btnNewButton_1 = new JButton("\u67E5\u8BE2");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				setVisible(false);
				new ResearchFrame().setVisible(true);
			}
		});
		btnNewButton_1.setVerticalAlignment(SwingConstants.BOTTOM);
		btnNewButton_1.setBounds(80, 0, 60, 80);
		contentPane.add(btnNewButton_1);
		
		
		JButton btnNewButton_2 = new JButton("\u7F16\u8F91");
		btnNewButton_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				setVisible(false);
				new AllOderFrame().setVisible(true);
			}
		});
		btnNewButton_2.setVerticalAlignment(SwingConstants.BOTTOM);
		btnNewButton_2.setBounds(146, 0, 60, 80);
		contentPane.add(btnNewButton_2);
		
		
		JButton btnNewButton_3 = new JButton("\u9000\u51FA");
		btnNewButton_3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				setVisible(false);
				System.exit(0);
			}
		});
		btnNewButton_3.setVerticalAlignment(SwingConstants.BOTTOM);
		btnNewButton_3.setBounds(216, 0, 60, 80);
		contentPane.add(btnNewButton_3);
		
		//Ϊ��ť��ͼƬ
		ImageIcon bg=new ImageIcon("src/pic/m01.gif");
		Image scaledImage = bg.getImage();
		bg.setImage(scaledImage);
		
		btnNewButton.setIcon(bg);
		btnNewButton.setVerticalTextPosition(SwingConstants.BOTTOM);
		btnNewButton.setHorizontalTextPosition(SwingConstants.CENTER);
		btnNewButton.setContentAreaFilled(false);
		btnNewButton.setBorder(new EmptyBorder(3, 3, 3, 3));
		
		ImageIcon bg1=new ImageIcon("src/pic/m06.gif");
		Image scaledImage1 = bg1.getImage();
		bg1.setImage(scaledImage1);
		
		btnNewButton_1.setIcon(bg1);
		btnNewButton_1.setVerticalTextPosition(SwingConstants.BOTTOM);
		btnNewButton_1.setHorizontalTextPosition(SwingConstants.CENTER);
		btnNewButton_1.setContentAreaFilled(false);
		btnNewButton_1.setBorder(new EmptyBorder(4, 4, 4, 4));
		
		ImageIcon bg2=new ImageIcon("src/pic/m04.gif");
		Image scaledImage2 = bg2.getImage();
		bg2.setImage(scaledImage2);
		
		btnNewButton_2.setIcon(bg2);
		btnNewButton_2.setVerticalTextPosition(SwingConstants.BOTTOM);
		btnNewButton_2.setHorizontalTextPosition(SwingConstants.CENTER);
		btnNewButton_2.setContentAreaFilled(false);
		btnNewButton_2.setBorder(new EmptyBorder(4, 4, 4, 4));
		
		ImageIcon bg3=new ImageIcon("src/pic/m10.gif");
		Image scaledImage3 = bg3.getImage();
		bg3.setImage(scaledImage3);
		
		btnNewButton_3.setIcon(bg3);
		btnNewButton_3.setVerticalTextPosition(SwingConstants.BOTTOM);
		btnNewButton_3.setHorizontalTextPosition(SwingConstants.CENTER);
		btnNewButton_3.setContentAreaFilled(false);
		btnNewButton_3.setBorder(new EmptyBorder(4, 4, 4, 4));
		
		CustomTableModel model = new CustomTableModel();
		String[] names = {"�ͻ�����", "��������","����ʱ��", "��ʼʱ��", "����ʱ��"};
		table = new JTable(model);
		model.setColumnNames(names);
		
		updateTable();
		model.setData(data);
		
		JScrollPane scrollPane = new JScrollPane(table);
		scrollPane.setBounds(20, 128, 383, 235);
		contentPane.add(scrollPane);
		
		JLabel label = new JLabel("\u8BA2\u5355\u4FE1\u606F\uFF1A");
		label.setForeground(Color.DARK_GRAY);
		label.setBackground(Color.GREEN);
		label.setFont(new Font("����", Font.PLAIN, 16));
		label.setBounds(20, 89, 90, 29);
		contentPane.add(label);
		
		
		
	}
	
	public void updateTable() {
		CustomerDAO customerDAO = new CustomerDAO();
		List<Customer> list =customerDAO.findAll();

		for (Customer customer : list) {
			Vector<Object> row = new Vector<Object>();
			
			row.add(customer.getName());
			
			String mtype = null ;
		    if(customer.getOther().equals("0")){
		    	mtype = "����";
		    }
		    else if(customer.getOther().equals("1")){
				mtype = "����";
			}
		    else if(customer.getOther().equals("2")) {
				mtype = "����";
			}
		    else if(customer.getOther().equals("3")) {
				mtype = "˫Ƥ��";
			}
		    row.add(mtype);
			row.add(customer.getPeriod());
			row.add(customer.getStarttime());
			row.add(customer.getEndtime());
			data.add(row);
		}	
	}
}
