package milkbar.ui;

import java.awt.Color;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;

import com.milkbar.constant.Constant;
import com.milkbar.dao.Customer;
import com.milkbar.dao.CustomerDAO;


public class NewOderFrame extends JFrame {

	private JPanel contentPane;
	private JTable table_1;
	private JTextField cusname;
	private JTextField milktype;
	private JTextField telnum;
	private JTextField ordertime;
	private JTextField address;
	private JTextField starttime;
	private JTextField endtime;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					NewOderFrame frame = new NewOderFrame();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public NewOderFrame() {
		setTitle("\u65B0\u589E\u8BA2\u5355");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 424, 394);
		contentPane = new JPanel();
		contentPane.setToolTipText("\u65B0\u589E\u8BA2\u5355");
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JButton btnNewButton = new JButton("\u6DFB\u52A0");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			    CustomerDAO customerDAO = new CustomerDAO();
			    
			    String nameString=cusname.getText().toString();	   
			    if(nameString.equals("")){
			    	JOptionPane.showMessageDialog(null, "���ֲ���Ϊ��");
			    	return;
			    }
			    String tel = telnum.getText().toString();			    
			    String add = address.getText().toString();
			    String per = ordertime.getText().toString();
			    String start = starttime.getText().toString();
			    String end = endtime.getText().toString();
			    String mtype = milktype.getText().toString(); 
			    
			    int type;
			    if(mtype.equals("����")){
			    	type = 0;
			    }
			    else if(mtype.equals("����")){
					type = 1;
				}
			    else if(mtype.equals("����")) {
					type = 2;
				}
			    else if(mtype.equals("˫Ƥ��")) {
					type = 3;
				}
			    else {
			    	JOptionPane.showMessageDialog(null, "��������ȷ������");
			    	return;
				}
			    
			   Customer customer =new Customer();
			   customer.setName(nameString);
			   customer.setTelnum(Integer.valueOf(tel));
			   customer.setAddress(add);
			   customer.setPeriod(per);
			   customer.setStarttime(start);
			   customer.setEndtime(end);
			   customer.setOther(String.valueOf(type));
			   
			   customerDAO.save(customer);
				//setVisible(false);
				//new MainFrame().setVisible(true);
			}
		});
		btnNewButton.setBounds(252, 252, 93, 23);
		contentPane.add(btnNewButton);
		
		JButton button = new JButton("\u53D6\u6D88");
		button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				setVisible(false);
				new MainFrame().setVisible(true);
			}
		});
		button.setBounds(252, 302, 93, 23);
		contentPane.add(button);
		
		JLabel label = new JLabel("\u8F93\u5165\u65B0\u589E\u8BA2\u5355\u4FE1\u606F\uFF1A");
		label.setFont(new Font("����", Font.PLAIN, 16));
		label.setForeground(Color.DARK_GRAY);
		label.setBounds(10, 10, 144, 22);
		contentPane.add(label);
		
		JLabel label_1 = new JLabel("\u5BA2\u6237\u59D3\u540D");
		label_1.setBounds(20, 42, 54, 15);
		contentPane.add(label_1);
		
		JLabel label_2 = new JLabel("\u8BA2\u5976\u54C1\u79CD");
		label_2.setBounds(20, 217, 54, 15);
		contentPane.add(label_2);
		
		JLabel label_3 = new JLabel("\u7535\u8BDD");
		label_3.setBounds(20, 82, 54, 15);
		contentPane.add(label_3);
		
		JLabel lblNewLabel = new JLabel("\u4F4F\u5740");
		lblNewLabel.setBounds(20, 166, 54, 15);
		contentPane.add(lblNewLabel);
		
		JLabel label_4 = new JLabel("\u8BA2\u5976\u65F6\u957F");
		label_4.setBounds(20, 264, 54, 15);
		contentPane.add(label_4);
		
		JLabel label_5 = new JLabel("\u5F00\u59CB\u65F6\u95F4");
		label_5.setBounds(20, 124, 54, 15);
		contentPane.add(label_5);
		
		JLabel label_6 = new JLabel("\u7ED3\u675F\u65F6\u95F4");
		label_6.setBounds(20, 306, 54, 15);
		contentPane.add(label_6);
		
		cusname = new JTextField();
		cusname.setBounds(75, 42, 66, 21);
		contentPane.add(cusname);
		cusname.setColumns(10);
		
		milktype = new JTextField();
		milktype.setBounds(75, 214, 66, 21);
		contentPane.add(milktype);
		milktype.setColumns(10);
		
		telnum = new JTextField();
		telnum.setBounds(75, 76, 66, 21);
		contentPane.add(telnum);
		telnum.setColumns(10);
		
		ordertime = new JTextField();
		ordertime.setBounds(75, 258, 66, 21);
		contentPane.add(ordertime);
		ordertime.setColumns(10);
		
		address = new JTextField();
		address.setBounds(75, 163, 66, 21);
		contentPane.add(address);
		address.setColumns(10);
		
		starttime = new JTextField();
		starttime.setBounds(75, 121, 66, 21);
		contentPane.add(starttime);
		starttime.setColumns(10);
		
		endtime = new JTextField();
		endtime.setBounds(75, 303, 66, 21);
		contentPane.add(endtime);
		endtime.setColumns(10);
		
		JPanel panel = new JPanel();
		panel.setBounds(182, 10, 216, 223);
		contentPane.add(panel);
		panel.setLayout(null);
		
		JLabel label_7 = new JLabel("\u5976\u79CD\u4E3A\uFF1A");
		label_7.setFont(new Font("��Բ", Font.PLAIN, 27));
		label_7.setForeground(Color.RED);
		label_7.setBounds(10, 10, 119, 56);
		panel.add(label_7);
		
		JLabel lblNewLabel_1 = new JLabel("\u9178\u5976                5\uFFE5");
		lblNewLabel_1.setBounds(10, 127, 82, 15);
		panel.add(lblNewLabel_1);
		
		JLabel lblNewLabel_2 = new JLabel("\u5E03\u4E01                5\uFFE5");
		lblNewLabel_2.setBounds(10, 162, 82, 15);
		panel.add(lblNewLabel_2);
		
		JLabel lblNewLabel_3 = new JLabel("\u53CC\u76AE\u5976              8\uFFE5");
		lblNewLabel_3.setBounds(10, 198, 82, 15);
		panel.add(lblNewLabel_3);
		
		JLabel label_8 = new JLabel("\u9C9C\u5976                5\uFFE5");
		label_8.setBounds(10, 91, 82, 15);
		panel.add(label_8);
		
		JLabel lblNewLabel_4 = new JLabel("\u5355\u4EF7");
		lblNewLabel_4.setFont(new Font("��Բ", Font.PLAIN, 29));
		lblNewLabel_4.setForeground(Color.BLUE);
		lblNewLabel_4.setBounds(139, 10, 67, 56);
		panel.add(lblNewLabel_4);
		
		JLabel label_9 = new JLabel("5\uFFE5");
		label_9.setBounds(139, 91, 54, 15);
		panel.add(label_9);
		
		JLabel label_10 = new JLabel("5\uFFE5");
		label_10.setBounds(139, 127, 54, 15);
		panel.add(label_10);
		
		JLabel label_11 = new JLabel("5\uFFE5");
		label_11.setBounds(139, 162, 54, 15);
		panel.add(label_11);
		
		JLabel label_12 = new JLabel("8\uFFE5");
		label_12.setBounds(139, 198, 54, 15);
		panel.add(label_12);
	}
}
