package milkbar.ui;

import java.awt.BorderLayout;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;
import javax.swing.JLabel;

import java.awt.Font;

import javax.swing.JTextField;
import javax.swing.JButton;

import com.milkbar.dao.Customer;
import com.milkbar.dao.CustomerDAO;

import uml.hotel.utils.CustomTableModel;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.util.List;
import java.util.Vector;



public class ResearchFrame extends JFrame {

	private JPanel contentPane;
	private final JScrollPane scrollPane = new JScrollPane();
	private JTable table;
	private JTable table1;
	private JTable table2;
	private JTable table3;
	private JTextField textField;
	private JButton btnNewButton;
	private Vector<Vector<Object>> data = new Vector<Vector<Object>>();
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					ResearchFrame frame = new ResearchFrame();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public ResearchFrame() {
		setTitle("\u67E5\u8BE2\u8BA2\u5355");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 492, 292);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		scrollPane.setBounds(10, 64, 441, 146);
		contentPane.add(scrollPane);
		
		
		
		table = new JTable();
		table.setModel(new DefaultTableModel(
			new Object[][] {
				{null, null, null, null, null, null, null},
				{null, null, null, null, null, null, null},
				{null, null, null, null, null, null, null},
				{null, null, null, null, null, null, null},
				{null, null, null, null, null, null, null},
				{null, null, null, null, null, null, null},
				{null, null, null, null, null, null, null},
			},
			new String[] {
					"�ͻ�����", "����Ʒ��", "�绰", "סַ", "����ʱ��", "��ʼʱ��", "����ʱ��"
			}
		));
		scrollPane.setViewportView(table);
		
		JPanel panel = new JPanel();
		panel.setBounds(0, 10, 451, 44);
		contentPane.add(panel);
		panel.setLayout(null);
		
		JLabel label = new JLabel("\u8F93\u5165\u5BA2\u6237\u540D\uFF1A");
		label.setFont(new Font("����", Font.PLAIN, 16));
		label.setBounds(10, 10, 96, 24);
		panel.add(label);
		
		textField = new JTextField();
		textField.setBounds(116, 13, 84, 21);
		panel.add(textField);
		textField.setColumns(10);
		
		JButton button = new JButton("\u67E5\u8BE2");
		button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {

				String input = textField.getText().toString();
				CustomTableModel model = new CustomTableModel();
				
				String[] names = {"�ͻ�����", "����Ʒ��", "�绰", "סַ", "����ʱ��", "��ʼʱ��", "����ʱ��"};
			    table.setVisible(false);
		    	
				
				if(input.equals("")){
					
					table1 = new JTable(model);
				    scrollPane.setViewportView(table1);
				    model.setColumnNames(names);
				    updateTable();
				    model.setData(data);
				    
				}else{
					data = new Vector<Vector<Object>>();
					CustomerDAO customerDAO = new CustomerDAO();
					List<Customer> list =customerDAO.findByName(input);
					
					table1 = new JTable(model);
				    scrollPane.setViewportView(table1);
				    model.setColumnNames(names);

					for (Customer customer : list) {

						Vector<Object> row = new Vector<Object>();
						
						row.add(customer.getName());
						
						String mtype = null ;
					    if(customer.getOther().equals("0")){
					    	mtype = "����";
					    }
					    else if(customer.getOther().equals("1")){
							mtype = "����";
						}
					    else if(customer.getOther().equals("2")) {
							mtype = "����";
						}
					    else if(customer.getOther().equals("3")) {
							mtype = "˫Ƥ��";
						}
					    row.add(mtype);
					    row.add(customer.getTelnum());
					    row.add(customer.getAddress());
						row.add(customer.getPeriod());
						row.add(customer.getStarttime());
						row.add(customer.getEndtime());
						data.add(row);
						model.setData(data);
						
					}
					
				}
			}
		});
		button.setBounds(349, 12, 71, 23);
		panel.add(button);
		
		btnNewButton = new JButton("\u8FD4\u56DE");
		btnNewButton.setFont(new Font("SimSun", Font.PLAIN, 12));
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				setVisible(false);
				new MainFrame().setVisible(true);
			}
		});
		btnNewButton.setBounds(372, 219, 93, 23);
		contentPane.add(btnNewButton);
	}
	
	public void updateTable() {
		data = new Vector<Vector<Object>>();
		CustomerDAO customerDAO = new CustomerDAO();
		List<Customer> list =customerDAO.findAll();

		for (Customer customer : list) {
			Vector<Object> row = new Vector<Object>();
			
			row.add(customer.getName());		
			String mtype = null ;
		    if(customer.getOther().equals("0")){
		    	mtype = "����";
		    }
		    else if(customer.getOther().equals("1")){
				mtype = "����";
			}
		    else if(customer.getOther().equals("2")) {
				mtype = "����";
			}
		    else if(customer.getOther().equals("3")) {
				mtype = "˫Ƥ��";
			}
		    row.add(mtype);
		    row.add(customer.getTelnum());
		    row.add(customer.getAddress());
			row.add(customer.getPeriod());
			row.add(customer.getStarttime());
			row.add(customer.getEndtime());
			data.add(row);
		}	
	}
}
